# Diattenuation Experiment
### Type1
### 04-18-17

This experiment utilized a type1 indoor houseplants
H,V,P,M measurements were acquired with filters placed in the role of generator.
This was useful for determining the diattenuation of the leafs response to unpolarized light.
The unpolarized lamp was found to be approximatley 9% polarized.

TODO: error correction should be made to account for this error.

The setup was a Stokes Polarimeter uses plastic linear polarizers.
Hand placement of filters resulted in rough estimates for each measurements.
This was done as an introduction to the idea of diattenuation of light incident on leaves.
