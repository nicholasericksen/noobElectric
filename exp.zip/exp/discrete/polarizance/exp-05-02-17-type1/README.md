## Background
A variety of different ages of leaves of type 1 outdoor variety are utilized in a discrete polarimeter setup.
The setup was performed by rotating plastic linear polarizers in front of a digital microscope.

# Conclusion
The results show that as the leaf ages the variance in the S1 and S2 polarization components that results increases.
The surface roughness causes an increase in the diffuse portion of scattering from the leafs surface.  As the surface becomes farther
away from being optically smooth...
