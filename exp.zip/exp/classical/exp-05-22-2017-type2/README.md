type 2 outdoor plant
no red filter
classical lmp
polarizance measurements
unpolarized srouce (~9%)


This plant was newly taken from an outdoor plant.
