## Background
This is an indoor waxy leaf (type 1) that has been removed from its host for approximately two weeks.
Classical LMP was employed in the role of the analyzer for calculation the polarizance components
of the leafs corresponding Mueller Matrix.

An unpolarized source was used in conjunction with a red filter.  

## Conclusion
The results showed...
