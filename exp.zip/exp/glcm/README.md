#Diattenuation EXP1

These are samples taken from the diattenuation experiment in order to test for glcm characteristics
A P filter is used in the image obtained.
